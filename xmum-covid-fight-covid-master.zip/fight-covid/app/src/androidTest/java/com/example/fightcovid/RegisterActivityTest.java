package com.example.fightcovid;

import androidx.test.espresso.action.ViewActions;
import androidx.test.espresso.matcher.ViewMatchers;
import androidx.test.ext.junit.runners.AndroidJUnit4;
import androidx.test.rule.ActivityTestRule;

import com.example.fightcovid.activity.RegisterActivity;

import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static androidx.test.espresso.Espresso.*;
import static androidx.test.espresso.action.ViewActions.click;
import static androidx.test.espresso.action.ViewActions.typeText;


@RunWith(AndroidJUnit4.class)
public class RegisterActivityTest {

    @Rule
    public ActivityTestRule<RegisterActivity> rule = new ActivityTestRule<>(RegisterActivity.class);

    @Test
    public void registerTest() {
        onView(ViewMatchers.withId(R.id.register_username_et))
                .perform(typeText("Test"), ViewActions.closeSoftKeyboard());
        onView(ViewMatchers.withId(R.id.register_password_et))
                .perform(typeText("Test"), ViewActions.closeSoftKeyboard());
        onView(ViewMatchers.withId(R.id.register_register_btn))
                .perform(click());
    }
}
