package com.example.fightcovid.fragment;

import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.fightcovid.R;
import com.example.fightcovid.adapter.NewsRecyclerViewAdapter;
import com.example.fightcovid.model.pojo.News;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;

public class NewsFragment extends Fragment {

    private List<News> news_list;
    private RecyclerView recyclerView;
    private Random random;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_news, container, false);
        random = new Random();

        news_list = new ArrayList<>();
        readJSON("un-news.json");

        recyclerView = view.findViewById(R.id.news_recyclerview);

        NewsRecyclerViewAdapter viewAdapter = new NewsRecyclerViewAdapter(view.getContext(), getNextBatch());
        recyclerView.setLayoutManager(new LinearLayoutManager(view.getContext()));
        recyclerView.setAdapter(viewAdapter);

        SwipeRefreshLayout refreshLayout = view.findViewById(R.id.swipe_news_layout);
        refreshLayout.setOnRefreshListener(() -> {
            viewAdapter.setmData(getNextBatch());
            viewAdapter.notifyDataSetChanged();
            refreshLayout.setRefreshing(false);
        });

        return view;
    }

    protected Boolean readJSON(String... strings) {
        AssetManager manager = getContext().getAssets();
        try (InputStreamReader isr = new InputStreamReader(
                manager.open(strings[0]),
                StandardCharsets.UTF_8);
             BufferedReader br = new BufferedReader(isr)) {
            Gson gson = new Gson();
            news_list = gson.fromJson(br, new TypeToken<List<News>>() {
            }.getType());
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
        return true;
    }

    private List<News> getNextBatch() {
        return random.ints(0, news_list.size() - 1)
                .limit(20)
                .mapToObj(i -> news_list.get(i))
                .collect(Collectors.toCollection(ArrayList::new));
    }

}
