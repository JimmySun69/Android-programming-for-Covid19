package com.example.fightcovid.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.fightcovid.R;

public class QuestionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qa);
    }
}