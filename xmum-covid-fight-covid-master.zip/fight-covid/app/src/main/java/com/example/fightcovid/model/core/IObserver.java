package com.example.fightcovid.model.core;

import android.content.Context;
import android.util.Log;
import android.widget.Toast;

import com.google.gson.JsonSyntaxException;

import io.reactivex.Observer;
import io.reactivex.disposables.Disposable;

public abstract class IObserver<T> implements Observer<T> {

    private static final String TAG = "Retrofit Connection";
    private final Context context;

    public IObserver(Context context) {
        this.context = context;
    }

    abstract public void onNext(T t);

    @Override
    public void onSubscribe(Disposable d) {
    }

    @Override
    public void onError(Throwable e) {
        if (e instanceof JsonSyntaxException) {
            Toast.makeText(context, "Sign In Successful", Toast.LENGTH_SHORT).show();
        }
        Log.d(TAG, "onError: ", e);
        Toast.makeText(context, "Unable to reach the Server", Toast.LENGTH_LONG).show();
    }

    @Override
    public void onComplete() {
    }
}
