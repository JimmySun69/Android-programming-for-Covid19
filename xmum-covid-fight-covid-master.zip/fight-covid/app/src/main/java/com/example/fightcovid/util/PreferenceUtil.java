package com.example.fightcovid.util;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.Map;

public class PreferenceUtil {

    public static final String FILE_NAME = "settings";

    private PreferenceUtil() {
    }

    public static String getString(Context context, String key) {
        return getPreference(context).getString(key, "");
    }

    public static void putString(Context context, String key, String value) {
        getPreference(context).edit().putString(key, value).apply();
    }

    public static void putStringMap(Context context, Map<String, String> map) {
        SharedPreferences.Editor edit = getPreference(context).edit();
        map.forEach(edit::putString);
        edit.apply();
    }

    private static SharedPreferences getPreference(Context context) {
        return context.getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
    }
}
