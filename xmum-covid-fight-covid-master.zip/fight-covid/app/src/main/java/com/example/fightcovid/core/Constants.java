package com.example.fightcovid.core;

public class Constants {
}
