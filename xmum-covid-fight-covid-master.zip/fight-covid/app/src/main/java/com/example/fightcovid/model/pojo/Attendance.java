package com.example.fightcovid.model.pojo;

import java.util.Date;

import io.reactivex.annotations.NonNull;

public class Attendance {
    private Long id;
    private String location;
    private String issuer;
    private Boolean healthy;
    private Date createTime;
    private Long userId;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getIssuer() {
        return issuer;
    }

    public void setIssuer(String issuer) {
        this.issuer = issuer;
    }

    public Boolean getHealthy() {
        return healthy;
    }

    public void setHealthy(Boolean healthy) {
        this.healthy = healthy;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    @NonNull
    @Override
    public String toString() {
        return "Attendance{" +
                "id=" + id +
                ", location='" + location + '\'' +
                ", issuer='" + issuer + '\'' +
                ", healthy=" + healthy +
                ", createTime=" + createTime +
                ", userId=" + userId +
                '}';
    }
}
