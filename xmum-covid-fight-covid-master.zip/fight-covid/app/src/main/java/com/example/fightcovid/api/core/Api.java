package com.example.fightcovid.api.core;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.ConcurrentHashMap;

import retrofit2.Retrofit;
import retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * 服务器已部署，api文档请访问
 * http://47.112.193.148:8080/docs
 */
public class Api {

    private Api() {
    }

    @SuppressWarnings("unchecked")
    public static <T> T get(Class<T> service) {
        if (!Holder.ioc.containsKey(service)) {
            T serviceImpl = Holder.retrofit.create(service);
            Holder.ioc.putIfAbsent(service, serviceImpl);
        }
        return (T) Holder.ioc.get(service);
    }

    private static class Holder {
        /**
         * Replace localhost to 10.0.2.2
         * which maps to the Host(Windows PC) instead of VM
         */
        private static final String BASE_URL = "http://47.112.193.148:8080/api/";
        private static ConcurrentHashMap<Object, Object> ioc = new ConcurrentHashMap<>();
        private static Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
                .addConverterFactory(GsonConverterFactory.create(
                        new GsonBuilder()
                                .setDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSX")
                                .serializeNulls()
                                .create()
                ))
                .build();
    }
}
