package com.example.fightcovid.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager.widget.ViewPager;

import com.example.fightcovid.R;
import com.example.fightcovid.adapter.ViewPagerAdapter;
import com.example.fightcovid.fragment.AccountFragment;
import com.example.fightcovid.fragment.HealthReminderFragment;
import com.example.fightcovid.fragment.MapFragment;
import com.example.fightcovid.fragment.NewsFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    private static boolean isExited = false;

    @SuppressLint("HandlerLeak")
    private static final Handler exitHandler = new Handler() {
        @Override
        public void handleMessage(@NonNull Message msg) {
            super.handleMessage(msg);
            isExited = false;
        }
    };

    @BindView(R.id.vp_main)
    ViewPager vpMain;
    @BindView(R.id.nav_bottom)
    BottomNavigationView navBottom;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        initViewPage();
        initBottomNav();
    }

    private void initViewPage() {
        ViewPagerAdapter adapter = new ViewPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new NewsFragment());
        adapter.addFragment(new MapFragment());
        adapter.addFragment(new HealthReminderFragment());
        adapter.addFragment(new AccountFragment());
        vpMain.setAdapter(adapter);
        vpMain.setCurrentItem(0);
        vpMain.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

            }

            @Override
            public void onPageSelected(int position) {
                navBottom.getMenu().getItem(position).setChecked(true);
            }

            @Override
            public void onPageScrollStateChanged(int state) {

            }
        });
    }

    private void initBottomNav() {
        navBottom.setOnNavigationItemSelectedListener(item -> {
            switch (item.getItemId()) {
                case R.id.nav_page_home:
                    vpMain.setCurrentItem(0);
                    break;
                case R.id.nav_page_map:
                    vpMain.setCurrentItem(1);
                    break;
                case R.id.nav_page_qa:
                    vpMain.setCurrentItem(2);
                    break;
                case R.id.nav_page_account:
                    vpMain.setCurrentItem(3);
                    break;
            }
            return true;
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        //Press 'back' twice to exit the program
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            exit();
            return false;
        }
        return super.onKeyDown(keyCode, event);
    }

    private void exit() {
        if (!isExited) {
            isExited = true;
            Toast.makeText(this, "Press Again to Exit", Toast.LENGTH_SHORT)
                    .show();
            exitHandler.sendEmptyMessageDelayed(0, 2000);
        } else {
            finish();
            System.exit(0);
        }
    }
}
