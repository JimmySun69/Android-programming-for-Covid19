package com.example.fightcovid.activity;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.example.fightcovid.R;
import com.example.fightcovid.adapter.HistoryItemAdapter;
import com.example.fightcovid.api.AttendanceService;
import com.example.fightcovid.api.core.Api;
import com.example.fightcovid.model.core.IObserver;
import com.example.fightcovid.model.core.IResponse;
import com.example.fightcovid.model.pojo.Attendance;
import com.example.fightcovid.util.PreferenceUtil;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class AttendanceActivity extends AppCompatActivity {

    @BindView(R.id.history_item_list)
    RecyclerView itemList;
    @BindView(R.id.swipe_refresh_layout)
    SwipeRefreshLayout refreshLayout;

    private Context context;
    private List<Attendance> records;
    private HistoryItemAdapter adapter;
    private AttendanceService attendanceService;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance);
        ButterKnife.bind(this);

        context = getApplicationContext();
        attendanceService = Api.get(AttendanceService.class);

        attendanceService.list(PreferenceUtil.getString(context, "token"))
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new IObserver<IResponse<List<Attendance>>>(context) {
                    @Override
                    public void onNext(IResponse<List<Attendance>> response) {
                        if (response.isSuccess()) {
                            records = response.getData();
                            adapter.setItems(records);
                            adapter.notifyDataSetChanged();
                        }
                    }
                });

        this.records = new ArrayList<>();
        adapter = new HistoryItemAdapter(this, records);
        itemList.setHasFixedSize(false);
        itemList.setItemAnimator(new DefaultItemAnimator());
        itemList.setLayoutManager(new LinearLayoutManager(this));
        itemList.setAdapter(adapter);

        refreshLayout.setColorSchemeColors(getResources().getColor(R.color.myAccentColor));
        refreshLayout.setOnRefreshListener(() -> {
            adapter.notifyDataSetChanged();
            refreshLayout.setRefreshing(false);
        });
    }
}
