package com.example.fightcovid.api;

import com.example.fightcovid.model.core.IResponse;
import com.example.fightcovid.model.pojo.User;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Query;

public interface UserService {

    @GET("user")
    Observable<IResponse<User>> info(@Query("token") String token);

    @PUT("user")
    Observable<IResponse<User>> updateInfo(@Query("token") String token, @Body User user);

    @POST("user/login")
    Observable<IResponse<String>> login(@Body User user);

    @POST("user/register")
    Observable<IResponse<Void>> register(@Body User user);
}
