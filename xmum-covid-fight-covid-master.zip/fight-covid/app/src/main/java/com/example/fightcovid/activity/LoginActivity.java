package com.example.fightcovid.activity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.fightcovid.R;
import com.example.fightcovid.api.core.Api;
import com.example.fightcovid.api.UserService;
import com.example.fightcovid.model.core.IObserver;
import com.example.fightcovid.model.core.IResponse;
import com.example.fightcovid.model.pojo.User;
import com.example.fightcovid.util.PreferenceUtil;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class LoginActivity extends AppCompatActivity {

    @BindView(R.id.username_et)
    EditText etUsername;
    @BindView(R.id.password_et)
    EditText etPassword;
    @BindView(R.id.login_bt)
    Button btnLogin;
    @BindView(R.id.register_tv)
    TextView tvRegister;

    SharedPreferences preferences;
    UserService userService = Api.get(UserService.class);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        ButterKnife.bind(this);

        preferences = getSharedPreferences(PreferenceUtil.FILE_NAME, MODE_PRIVATE);
        etUsername.setText(preferences.getString("username", ""));
        etPassword.setText(preferences.getString("password", ""));
    }

    @OnClick({R.id.login_bt, R.id.register_tv})
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.register_tv:
                startActivity(new Intent(this, RegisterActivity.class));
                break;
            case R.id.login_bt:
                String username = etUsername.getText().toString().trim();
                String password = etPassword.getText().toString().trim();
                this.login(username, password);
                break;
            default:
                throw new IllegalStateException("Unexpected value: " + view.getId());
        }
    }

    private void login(String username, String password) {
        if (username.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Username or Password cannot be Empty"
                    , Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        userService.login(user)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new IObserver<IResponse<String>>(this) {
                    @Override
                    public void onNext(IResponse<String> response) {
                        if (response.isSuccess()) {
                            preferences.edit()
                                    .putString("username", username)
                                    .putString("password", password)
                                    .putString("token", response.getData())
                                    .apply();
                            Toast.makeText(LoginActivity.this, "login successfully", Toast.LENGTH_SHORT)
                                    .show();
                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(intent);
                        } else {
                            preferences.edit().clear().apply();
                            Toast.makeText(LoginActivity.this, "invalid username or password", Toast.LENGTH_SHORT)
                                    .show();
                        }
                    }
                });
    }
}
