package com.example.fightcovid.model.pojo;

import java.time.LocalDateTime;

public class HistoryRecord {
    private String locationName;
    private String checkInBy;
    private boolean healthy;
    private LocalDateTime checkInTime;
    private Long longitude;
    private Long latitude;

    public String getLocationName() {
        return locationName;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    public String getCheckInBy() {
        return checkInBy;
    }

    public void setCheckInBy(String checkInBy) {
        this.checkInBy = checkInBy;
    }

    public boolean isHealthy() {
        return healthy;
    }

    public void setHealthy(boolean healthy) {
        this.healthy = healthy;
    }

    public LocalDateTime getCheckInTime() {
        return checkInTime;
    }

    public void setCheckInTime(LocalDateTime checkInTime) {
        this.checkInTime = checkInTime;
    }

    public Long getLongitude() {
        return longitude;
    }

    public void setLongitude(Long longitude) {
        this.longitude = longitude;
    }

    public Long getLatitude() {
        return latitude;
    }

    public void setLatitude(Long latitude) {
        this.latitude = latitude;
    }

    @Override
    public String toString() {
        return "HistoryRecord{" +
                "locationName='" + locationName + '\'' +
                ", checkInBy='" + checkInBy + '\'' +
                ", healthy=" + healthy +
                ", checkInTime=" + checkInTime +
                ", longitude=" + longitude +
                ", latitude=" + latitude +
                '}';
    }
}
