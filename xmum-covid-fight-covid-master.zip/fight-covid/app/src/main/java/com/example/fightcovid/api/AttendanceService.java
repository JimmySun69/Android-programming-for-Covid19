package com.example.fightcovid.api;

import com.example.fightcovid.model.core.IResponse;
import com.example.fightcovid.model.pojo.Attendance;

import java.util.List;

import io.reactivex.Observable;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface AttendanceService {
    @GET("attendance")
    Observable<IResponse<List<Attendance>>> list(@Query("token") String token);

    @POST("attendance")
    Observable<IResponse<Void>> singUp(@Query("token") String token, @Body Attendance attendance);
}
