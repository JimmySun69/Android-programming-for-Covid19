package com.example.fightcovid.model.pojo;

public class SingleRecord {
    private String location;
    private Integer confirmed;
    private Integer recovered;
    private Integer active;

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public Integer getConfirmed() {
        return confirmed;
    }

    public void setConfirmed(Integer confirmed) {
        this.confirmed = confirmed;
    }

    public Integer getRecovered() {
        return recovered;
    }

    public void setRecovered(Integer recovered) {
        this.recovered = recovered;
    }

    public Integer getActive() {
        return active;
    }

    public void setActive(Integer active) {
        this.active = active;
    }

    @Override
    public String toString() {
        return "Record{" +
                "location='" + location + '\'' +
                ", confirmed=" + confirmed +
                ", recovered=" + recovered +
                ", active=" + active +
                '}';
    }
}
