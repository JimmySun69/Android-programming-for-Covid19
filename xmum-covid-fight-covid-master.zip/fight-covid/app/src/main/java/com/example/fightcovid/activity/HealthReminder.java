package com.example.fightcovid.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fightcovid.R;

public class HealthReminder extends AppCompatActivity {

    private Button btn, btn1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_health_reminder);
        btn = findViewById(R.id.btn_reminder_no);
        btn1 = findViewById(R.id.btn_reminder_yes);
        btn.setOnClickListener(view -> openActivity());
        btn1.setOnClickListener(v -> openActivity1());
    }

    public void openActivity() {
        Intent intent = new Intent(this, AssessmentActivity.class);
        startActivity(intent);
    }

    public void openActivity1() {
        Intent intent = new Intent(this, QuestionActivity.class);
        startActivity(intent);
    }
}