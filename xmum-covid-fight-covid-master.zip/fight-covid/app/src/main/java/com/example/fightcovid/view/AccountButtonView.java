package com.example.fightcovid.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;


import com.example.fightcovid.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AccountButtonView extends RelativeLayout {

    @BindView(R.id.view_account_icon)
    ImageView icon;
    @BindView(R.id.view_account_description)
    TextView description;
    @BindView(R.id.view_account_value)
    TextView value;

    public AccountButtonView(Context context) {
        super(context);
    }

    public AccountButtonView(Context context, AttributeSet attrs) {
        super(context, attrs);
        LayoutInflater.from(context).inflate(R.layout.view_account_button, this);
        ButterKnife.bind(this, this);

        TypedArray typedArray = context.obtainStyledAttributes(attrs, R.styleable.AccountButtonView);
        icon.setImageDrawable(typedArray.getDrawable(R.styleable.AccountButtonView_left_icon));
        description.setText(typedArray.getText(R.styleable.AccountButtonView_left_description));
        value.setText(typedArray.getText(R.styleable.AccountButtonView_right_value));
        typedArray.recycle();
    }

    public void setRightText(String text) {
        value.setText(text);
    }
}
