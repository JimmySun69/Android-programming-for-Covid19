package com.example.fightcovid.fragment;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.fightcovid.R;
import com.example.fightcovid.activity.AssessmentActivity;
import com.example.fightcovid.activity.QuestionActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class HealthReminderFragment extends Fragment {

    @BindView(R.id.btn_reminder_yes)
    Button buttonYes;
    @BindView(R.id.btn_reminder_no)
    Button buttonNo;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.activity_health_reminder, container, false);
        ButterKnife.bind(this, rootView);
        return rootView;
    }

    @OnClick(R.id.btn_reminder_yes)
    public void onYesClick() {
        startActivity(new Intent(getContext(), AssessmentActivity.class));
    }

    @OnClick(R.id.btn_reminder_no)
    public void onNoClick() {
        startActivity(new Intent(getContext(), QuestionActivity.class));
    }
}
