package com.example.fightcovid.view;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.drawable.ColorDrawable;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.PopupWindow;


import com.example.fightcovid.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PhotoPopupWindow extends PopupWindow {

    @BindView(R.id.icon_btn_camera)
    Button btnCamera;
    @BindView(R.id.icon_btn_select)
    Button btnAlbum;
    @BindView(R.id.icon_btn_cancel)
    Button btnCancel;

    @SuppressLint("ClickableViewAccessibility")
    public PhotoPopupWindow(Context context, View.OnClickListener albumOnClickListener,
                            View.OnClickListener cameraOnClickListener) {
        super(context);

        View rootView = LayoutInflater.from(context).inflate(R.layout.pop_item, null);
        ButterKnife.bind(this, rootView);

        btnAlbum.setOnClickListener(albumOnClickListener);
        btnCamera.setOnClickListener(cameraOnClickListener);
        btnCancel.setOnClickListener(v -> dismiss());

        this.setContentView(rootView);
        this.setAnimationStyle(R.style.pop_window_anim_style);
        this.setWidth(WindowManager.LayoutParams.MATCH_PARENT);
        this.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);
        this.setFocusable(true);

        ColorDrawable drawable = new ColorDrawable(0x0000000);
        this.setBackgroundDrawable(drawable);

        rootView.setOnTouchListener((v, event) -> {
            int height = rootView.findViewById(R.id.ll_pop).getTop();
            int y = (int) event.getY();
            if (event.getAction() == MotionEvent.ACTION_UP) {
                if (y < height) {
                    dismiss();
                }
            }
            return true;
        });
    }
}
