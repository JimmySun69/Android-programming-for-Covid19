package com.example.fightcovid.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;


import com.example.fightcovid.R;
import com.example.fightcovid.api.core.Api;
import com.example.fightcovid.api.UserService;
import com.example.fightcovid.model.core.IObserver;
import com.example.fightcovid.model.core.IResponse;
import com.example.fightcovid.model.pojo.User;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;

public class RegisterActivity extends AppCompatActivity {

    @BindView(R.id.register_username_et)
    EditText etUsername;
    @BindView(R.id.register_password_et)
    EditText etPassword;
    @BindView(R.id.register_phone_et)
    EditText etPhone;
    @BindView(R.id.register_register_btn)
    Button btnSubmit;

    UserService userService = Api.get(UserService.class);

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        ButterKnife.bind(this);
    }


    @OnClick(R.id.register_register_btn)
    public void onViewClicked() {
        String username = etUsername.getText().toString().trim();
        String password = etPassword.getText().toString().trim();
        String phone = etPhone.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
            Toast.makeText(this, "Please fill in all the blanks!", Toast.LENGTH_SHORT).show();
            return;
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setPhone(phone);
        userService.register(user)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new IObserver<IResponse<Void>>(this) {
                    @Override
                    public void onNext(IResponse<Void> response) {
                        if (response.isSuccess()) {
                            Toast.makeText(RegisterActivity.this, "Register Successfully", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
                        } else {
                            Toast.makeText(RegisterActivity.this, "Username already exists!", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
