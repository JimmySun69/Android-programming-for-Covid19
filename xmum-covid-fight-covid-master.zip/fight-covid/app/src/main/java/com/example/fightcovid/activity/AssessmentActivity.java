package com.example.fightcovid.activity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RatingBar;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fightcovid.R;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;

public class AssessmentActivity extends AppCompatActivity {

    public static final String EXTRA_NUMBER = "com.example.application.example.EXTRA_NUMBER";
    public static final String EXTRA_NUMBER_1 = "com.example.application.example.EXTRA_NUMBER_1";
    public static final String EXTRA_NUMBER_2 = "com.example.application.example.EXTRA_NUMBER_2";
    public static final String EXTRA_NUMBER_3 = "com.example.application.example.EXTRA_NUMBER_3";
    public static final String EXTRA_NUMBER_4 = "com.example.application.example.EXTRA_NUMBER_4";
    public static final String EXTRA_NUMBER_5 = "com.example.application.example.EXTRA_NUMBER_5";

    @BindView(R.id.editName)
    EditText editName;
    @BindView(R.id.editEmail)
    EditText editEmail;
    @BindView(R.id.ratingLikely)
    RatingBar ratingLikely;
    @BindView(R.id.ratingMask)
    RatingBar ratingMask;
    @BindView(R.id.ratingHand)
    RatingBar ratingHand;
    @BindView(R.id.ratingSleep)
    RatingBar ratingSleep;
    @BindView(R.id.ratingHome)
    RatingBar ratingHome;
    @BindView(R.id.radioGroupSymptom)
    RadioGroup radioGroupSymptom;
    @BindView(R.id.radioGroupTemperature)
    RadioGroup radioGroupTemperature;
    @BindView(R.id.btn_submit_form)
    Button submitForm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_assessment);
        ButterKnife.bind(this);
    }

    @OnClick(R.id.btn_submit_form)
    public void onClick() {
        String name = editName.getText().toString();
        String email = editEmail.getText().toString();
        float ratingLikelyFloat = ratingLikely.getRating();

        RatingBar[] ratings = new RatingBar[]{ratingMask, ratingHand, ratingSleep, ratingHome};
        float ratingSum = 0.0f;
        for (RatingBar bar : ratings) {
            ratingSum += bar.getRating();
        }

        RadioButton symptomSelected = findViewById(radioGroupSymptom.getCheckedRadioButtonId());
        RadioButton temperatureSelect = findViewById(radioGroupTemperature.getCheckedRadioButtonId());

        Intent intent = new Intent(this, SummaryActivity.class);
        intent.putExtra(EXTRA_NUMBER, ratingLikelyFloat);
        intent.putExtra(EXTRA_NUMBER_1, ratingSum);
        intent.putExtra(EXTRA_NUMBER_2, name);
        intent.putExtra(EXTRA_NUMBER_3, email);
        intent.putExtra(EXTRA_NUMBER_4, symptomSelected.getText().toString());
        intent.putExtra(EXTRA_NUMBER_5, temperatureSelect.getText().toString());

        startActivity(intent);
    }

}