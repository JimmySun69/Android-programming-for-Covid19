package com.example.fightcovid.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.bumptech.glide.Glide;
import com.example.fightcovid.R;
import com.example.fightcovid.model.pojo.Attendance;
import com.example.fightcovid.model.pojo.HistoryRecord;

import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class HistoryItemAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {

    private final Context context;
    private List<Attendance> items;

    public HistoryItemAdapter(Context context, List<Attendance> items) {
        this.context = context;
        this.items = items;
    }

    public void setItems(List<Attendance> items) {
        this.items = items;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View root = View.inflate(parent.getContext(), R.layout.view_history_item, null);
        return new ContentViewHolder(root);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        ContentViewHolder viewHolder = (ContentViewHolder) holder;
        //Set Default Value
        Attendance attendance = items.get(position);
        Glide.with(context)
                .load("https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=1062518936,3213620798&fm=26&gp=0.jpg")
                .placeholder(R.drawable.ic_empty_image)
                .into(viewHolder.historyImage);

        viewHolder.checkInTime.setText(attendance.getCreateTime().toString());
        viewHolder.signature.setText(attendance.getIssuer());
        viewHolder.status.setText(attendance.getHealthy() ? "normal" : "abnormal");
        viewHolder.location.setText(attendance.getLocation());
        viewHolder.errorButton.setOnClickListener(v -> new MaterialDialog.Builder(context)
                .theme(Theme.LIGHT)
                .title("Report An Error?")
                .titleColorRes(R.color.dlgTitleColor)
                .content("Would you like to report an error of the attendance?")
                .positiveText("Yes")
                .negativeText("No")
                .onPositive(((dialog, which) -> Toast.makeText(context, "Thanks for your report!", Toast.LENGTH_SHORT).show()))
                .show());
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class ContentViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.history_image)
        ImageView historyImage;
        @BindView(R.id.history_item_time)
        TextView checkInTime;
        @BindView(R.id.history_item_signature)
        TextView signature;
        @BindView(R.id.history_item_status)
        TextView status;
        @BindView(R.id.history_location)
        TextView location;
        @BindView(R.id.history_error)
        ImageButton errorButton;

        public ContentViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
