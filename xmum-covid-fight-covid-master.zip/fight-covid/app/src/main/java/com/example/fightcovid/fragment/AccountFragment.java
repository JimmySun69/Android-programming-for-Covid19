package com.example.fightcovid.fragment;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.afollestad.materialdialogs.DialogAction;
import com.afollestad.materialdialogs.MaterialDialog;
import com.afollestad.materialdialogs.Theme;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.example.fightcovid.R;
import com.example.fightcovid.activity.AttendanceActivity;
import com.example.fightcovid.api.AttendanceService;
import com.example.fightcovid.api.UserService;
import com.example.fightcovid.api.core.Api;
import com.example.fightcovid.model.core.IObserver;
import com.example.fightcovid.model.core.IResponse;
import com.example.fightcovid.model.pojo.Attendance;
import com.example.fightcovid.model.pojo.User;
import com.example.fightcovid.util.PreferenceUtil;
import com.example.fightcovid.view.AccountButtonView;
import com.example.fightcovid.view.PhotoPopupWindow;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.jph.takephoto.app.TakePhoto;
import com.jph.takephoto.app.TakePhotoFragment;
import com.jph.takephoto.model.TImage;
import com.jph.takephoto.model.TResult;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.Date;

import butterknife.BindView;
import butterknife.ButterKnife;
import io.reactivex.android.schedulers.AndroidSchedulers;
import io.reactivex.schedulers.Schedulers;
import jp.wasabeef.glide.transformations.CropCircleTransformation;

public class AccountFragment extends TakePhotoFragment {

    private static final String TAG = "AccountFragment";

    @BindView(R.id.account_iv_background)
    ImageView ivBackground;
    @BindView(R.id.account_iv_avatar)
    ImageView ivAvatar;
    @BindView(R.id.account_tv_username)
    TextView tvUsername;
    @BindView(R.id.account_view_username)
    AccountButtonView buttonUsername;
    @BindView(R.id.account_view_phone)
    AccountButtonView buttonPhone;
    @BindView(R.id.account_view_password)
    AccountButtonView buttonPassword;
    @BindView(R.id.account_view_health)
    AccountButtonView buttonHealth;
    @BindView(R.id.account_view_history)
    AccountButtonView buttonHistory;

    private User user;
    private String token;
    private Context context;
    private PhotoPopupWindow popupWindow;
    private UserService userService;
    private AttendanceService attendanceService;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_account, container, false);
        ButterKnife.bind(this, rootView);

        context = getContext();
        userService = Api.get(UserService.class);
        attendanceService = Api.get(AttendanceService.class);
        token = PreferenceUtil.getString(context, "token");

        //default user
        user = new User();
        user.setUsername("");
        user.setPhone("");

        userService.info(token)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new IObserver<IResponse<User>>(context) {
                    @Override
                    public void onNext(IResponse<User> response) {
                        if (response.isSuccess()) {
                            user = response.getData();
                            tvUsername.setText(user.getUsername());
                            buttonUsername.setRightText(user.getUsername());
                            buttonPhone.setRightText(user.getPhone());
                        }
                    }
                });

        File avatar = new File(context.getFilesDir(), "avatar.jpg");
        if (avatar.exists()) {
            Glide.with(context)
                    .load(avatar)
                    .skipMemoryCache(true)
                    .diskCacheStrategy(DiskCacheStrategy.NONE)
                    .bitmapTransform(new CropCircleTransformation(context))
                    .into(ivAvatar);
        } else {
            Glide.with(context)
                    .load(R.drawable.ic_default_avatar)
                    .bitmapTransform(new CropCircleTransformation(context))
                    .into(ivAvatar);
        }

        //用户名点击事件
        buttonUsername.setOnClickListener(v -> new MaterialDialog.Builder(context)
                .theme(Theme.LIGHT)
                .title("Edit Username")
                .content("Please enter new username")
                .positiveText("APPLY")
                .positiveColorRes(R.color.red)
                .negativeText("CANCEL")
                .inputType(InputType.TYPE_CLASS_TEXT)
                .inputRangeRes(1, 16, R.color.colorPrimary)
                .input("Please Enter new Username", user.getUsername(), (dialog, input) -> {
                    dialog.getActionButton(DialogAction.POSITIVE).setEnabled(input.length() != 0);
                })
                .onPositive((dialog, which) -> {
                    user.setUsername(dialog.getInputEditText().getText().toString());
                    this.updateUserInfo();
                    tvUsername.setText(user.getUsername());
                    buttonUsername.setRightText(user.getUsername());
                })
                .show()
        );

        //手机号点击事件
        buttonPhone.setOnClickListener(v -> new MaterialDialog.Builder(context)
                .theme(Theme.LIGHT)
                .title("Edit Phone Number")
                .content("Please enter new username")
                .positiveText("APPLY")
                .positiveColorRes(R.color.red)
                .negativeText("CANCEL")
                .inputType(InputType.TYPE_CLASS_PHONE)
                .inputRangeRes(1, 12, R.color.colorPrimary)
                .input("Please Enter new Phone Number", user.getPhone(), (dialog, input) -> {
                    dialog.getActionButton(DialogAction.POSITIVE).setEnabled(input.length() != 0);
                })
                .onPositive((dialog, which) -> {
                    user.setPhone(dialog.getInputEditText().getText().toString());
                    this.updateUserInfo();
                    buttonPhone.setRightText(user.getPhone());
                })
                .show()
        );

        //密码点击事件
        buttonPassword.setOnClickListener(v -> new MaterialDialog.Builder(context)
                .theme(Theme.LIGHT)
                .title("Edit Password")
                .content("Please enter new password")
                .positiveText("APPLY")
                .positiveColorRes(R.color.red)
                .negativeText("CANCEL")
                .inputType(InputType.TYPE_TEXT_VARIATION_PASSWORD)
                .inputRangeRes(1, 12, R.color.colorPrimary)
                .input("Please Enter new Phone Password", "", (dialog, input) -> {
                    dialog.getActionButton(DialogAction.POSITIVE).setEnabled(input.length() != 0);
                })
                .onPositive((dialog, which) -> {
                    user.setPassword(dialog.getInputEditText().getText().toString());
                    this.updateUserInfo();
                })
                .show()
        );

        //头像点击事件
        ivAvatar.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.WRITE_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            }
            popupWindow = new PhotoPopupWindow(context, v1 -> {
                //Gallery On Click Listener
                TakePhoto takePhoto = getTakePhoto();
                takePhoto.onPickFromGallery();
                popupWindow.dismiss();
            }, v2 -> {
                //Camera On Click Listener
                File pathFile = new File(context.getFilesDir(), "avatar.jpg");
                Log.d(TAG, "onCreateView: FilePath:" + pathFile.getAbsolutePath());
                getTakePhoto().onPickFromCapture(Uri.fromFile(pathFile));
                popupWindow.dismiss();
            });
            popupWindow.showAtLocation(rootView, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL
                    , 0, 0);
        });

        //健康码点击事件
        buttonHealth.setOnClickListener(v -> {
            IntentIntegrator.forSupportFragment(this)
                    .setPrompt("Please Scan inside the Rectangle")
                    .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
                    .setBeepEnabled(true)
                    .initiateScan();
        });

        //历史按钮
        buttonHistory.setOnClickListener(v -> {
            Intent intent = new Intent(context, AttendanceActivity.class);
            startActivity(intent);
        });

        return rootView;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(context, "Cancelled", Toast.LENGTH_SHORT).show();
            } else {
                Gson gson = new Gson();
                Attendance attendance = gson.fromJson(result.getContents(), Attendance.class);
                attendance.setUserId(user.getId());
                attendance.setHealthy(true);
                attendance.setCreateTime(new Date());
                attendanceService.singUp(token, attendance)
                        .subscribeOn(Schedulers.io())
                        .observeOn(AndroidSchedulers.mainThread())
                        .subscribe(new IObserver<IResponse<Void>>(context) {
                            @Override
                            public void onNext(IResponse<Void> response) {
                                if (response.isSuccess()) {
                                    Toast.makeText(context, "Sign In Successful", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(context, "Error", Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }

    @Override
    public void takeSuccess(TResult result) {
        super.takeSuccess(result);
        TImage resultImage = result.getImage();
        File targetFile = new File(context.getFilesDir(), "avatar.jpg");
        File imgFile = new File(resultImage.getOriginalPath());

        Log.d(TAG, "takeSuccess: File Path: " + imgFile.getAbsolutePath());
        Log.d(TAG, "takeSuccess: File Exists: " + imgFile.exists());
        Log.d(TAG, "takeSuccess: File Can Read: " + imgFile.canRead());
        Log.d(TAG, "takeSuccess: File Can Write: " + imgFile.canWrite());

        if (!imgFile.getAbsolutePath().equals(targetFile.getAbsolutePath())) {
            try {
                Files.copy(imgFile.toPath(), targetFile.toPath(), StandardCopyOption.REPLACE_EXISTING);
            } catch (IOException e) {
                Log.d(TAG, "takeSuccess: I/O Exception", e);
                Toast.makeText(context, "I/O Exception", Toast.LENGTH_SHORT).show();
                return;
            }
        }

        Glide.with(context)
                .load(Uri.fromFile(imgFile))
                .skipMemoryCache(true)
                .diskCacheStrategy(DiskCacheStrategy.NONE)
                .bitmapTransform(new CropCircleTransformation(context))
                .into(ivAvatar);

        Toast.makeText(context, "Avatar Update Successfully", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void takeFail(TResult result, String msg) {
        super.takeFail(result, msg);
        Toast.makeText(context, "Avatar Update Failed: " + msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void takeCancel() {
        super.takeCancel();
        Toast.makeText(context, "Avatar Update cancelled", Toast.LENGTH_SHORT).show();
    }

    private void updateUserInfo() {
        userService.updateInfo(token, user)
                .subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .subscribe(new IObserver<IResponse<User>>(context) {
                    @Override
                    public void onNext(IResponse<User> response) {
                        if (response.isSuccess()) {
                            tvUsername.setText(user.getUsername());
                            buttonUsername.setRightText(user.getUsername());
                            PreferenceUtil.putString(context, "username", user.getUsername());
                            Toast.makeText(context, "Update Successfully", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(context, response.getMsg(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }
}
