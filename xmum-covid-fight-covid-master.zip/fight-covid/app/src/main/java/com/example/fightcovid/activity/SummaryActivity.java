package com.example.fightcovid.activity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.example.fightcovid.R;

public class SummaryActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_summary);
        Intent intent = getIntent();

        float val1 = intent.getFloatExtra(AssessmentActivity.EXTRA_NUMBER, 0.0f);
        float val2 = intent.getFloatExtra(AssessmentActivity.EXTRA_NUMBER_1, 0.0f);
        String name = intent.getStringExtra(AssessmentActivity.EXTRA_NUMBER_2);
        String email = intent.getStringExtra(AssessmentActivity.EXTRA_NUMBER_3);
        String btn1 = intent.getStringExtra(AssessmentActivity.EXTRA_NUMBER_4);
        String btn2 = intent.getStringExtra(AssessmentActivity.EXTRA_NUMBER_5);
        TextView txt1 = findViewById(R.id.textView18);
        TextView txt2 = findViewById(R.id.textView19);

        TextView txt3 = findViewById(R.id.textView15);
        TextView txt4 = findViewById(R.id.textView16);

        TextView txt5 = findViewById(R.id.textView20);
        TextView txt6 = findViewById(R.id.textView21);

        TextView txt7 = findViewById(R.id.textView23);

        txt1.setText(String.valueOf(val1));
        txt2.setText(String.valueOf(val2));

        txt3.setText(name);
        txt4.setText(email);

        txt5.setText(btn1);
        txt6.setText(btn2);

        if (val1 > 3) {
            if (val2 < 14)
                txt7.setText("You are very likely to get infected ");
            else
                txt7.setText("You can be too cautious ");
        } else {
            if (val2 < 16) {
                txt7.setText("You can be infected, take care ");
            } else {
                txt7.setText("You are very likely to be healthy ");
            }
        }

    }
}